/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import javax.swing.ImageIcon;

/**
 *
 * @author Yendry Leon C24251
 */
public class Principal extends Elemento
{
    private int vidas;

    
    
    public Principal(int X, int y, ImageIcon imagen) 
    {
        super(X, y, imagen);
    }

    
    public Principal(int vidas, int X, int y, ImageIcon imagen) 
    {
        super(X, y, imagen);
        this.vidas = vidas;
    }
    
}
