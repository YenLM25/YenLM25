/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author Yendry Leon C24251
 */
public class Elemento 
{
    private int X ;
   private int y;
   private ImageIcon imagen;
   

    public Elemento(int X, int y, ImageIcon imagen) 
    {
        this.X = X;
        this.y = y;
        this.imagen = imagen;
    }

    public int getX() 
    {
        return X;
    }

    public void setX(int X) 
    {
        this.X = X;
    }

    public int getY() 
    {
        return y;
    }

    public void setY(int y) 
    {
        this.y = y;
    }

    public ImageIcon getImagen() 
    {
        return imagen;
    }

    public void setImagen(ImageIcon imagen) 
    {
        this.imagen = imagen;
    }
   
       public Rectangle getBounds()
    {
       return new Rectangle(X, y, imagen.getIconHeight(), imagen.getIconWidth());
    }
       
       
   public void show(Graphics g)
   {
       imagen.paintIcon(null, g, X, y);
   }
}
