/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Yendry Leon Matarrita C24251
 */
public class Laberinto
{
    private String[][] laberinto;
    
    
    
    public Laberinto()
    {
        laberinto = new String[][]
        {
                 //  0     1   2    3    4    5    6    7    8    9   10   11    12   13  14    15   16   17
           /**0*/  {"p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p"},

           /**1*/  {"c", "c", "c", "c", "c", "c", "c", "p", "c", "c", "c", "c", "c", "p", "c", "c", "c", "p"},

           /**2*/  {"p", "p", "p", "p", "c", "p", "p", "p", "p", "p", "c", "p", "c", "c", "c", "p", "c", "p"},

           /**3*/  {"p", "c", "c", "c", "c", "p", "c", "c", "c", "c", "c", "p", "p", "c", "p", "p", "p", "p"},

           /**4*/  {"p", "c", "p", "p", "p", "p", "p", "c", "p", "p", "c", "c", "p", "c", "c", "c", "c", "p"},

           /**5*/  {"p", "c", "p", "c", "c", "c", "c", "c", "c", "p", "c", "p", "p", "p", "p", "p", "p", "p"},

           /**6*/  {"p", "c", "p", "p", "p", "c", "p", "p", "c", "p", "c", "p", "c", "c", "c", "c", "c", "p"},

           /**7*/  {"p", "c", "c", "c", "c", "c", "p", "c", "c", "p", "c", "p", "c", "p", "p", "p", "c", "p"},

           /**8*/  {"p", "p", "p", "p", "p", "p", "p", "c", "c", "p", "p", "p", "c", "c", "c", "p", "c", "p"},

           /**9*/  {"p", "c", "c", "p", "c", "c", "c", "c", "c", "c", "c", "p", "c", "p", "p", "p", "c", "p"},

           /**10*/ {"p", "c", "c", "c", "c", "p", "p", "p", "p", "p", "c", "p", "c", "p", "c", "c", "c", "p"},

           /**11*/ {"p", "c", "p", "c", "c", "p", "c", "c", "c", "c", "c", "p", "c", "p", "c", "p", "p", "p"},

           /**12*/ {"p", "c", "p", "c", "p", "p", "c", "p", "p", "p", "p", "p", "c", "p", "c", "p", "c", "p"},

           /**13*/ {"p", "c", "p", "c", "c", "p", "c", "c", "c", "c", "c", "c", "c", "p", "c", "p", "c", "p"},

           /**14*/ {"p", "p", "p", "c", "c", "p", "p", "p", "p", "p", "p", "p", "p", "p", "c", "c", "c", "p"},

           /**15*/ {"p", "c", "p", "p", "c", "c", "p", "c", "c", "c", "c", "c", "c", "p", "p", "p", "c", "p"},

           /**16*/ {"p", "c", "c", "c", "c", "c", "c", "c", "c", "c", "p", "c", "c", "c", "c", "p", "c", "p"},

           /**17*/ {"p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "p", "c", "p"}
        };
    }
    
       public boolean esCasillaDeCamino(int x, int y, int altura, int ancho) 
       {
            int filaInicio = y / altura;
            int columnaInicio = x / ancho;
            int filaFin = (y + altura) / altura;
            int columnaFin = (x + ancho) / ancho;

            for (int i = filaInicio; i < filaFin; i++) 
            {
                for (int j = columnaInicio; j < columnaFin; j++) 
                {
                    if (i >= 0 && i < laberinto.length && j >= 0 && j < laberinto[0].length && laberinto[i][j].equals("p")) 
                    {
                        System.out.println("El heroe ha chocado con una pared");
                        return false; // La casilla es una pared
                    }
                }
            }
            return true; // La casilla es de camino
        }

    

}
