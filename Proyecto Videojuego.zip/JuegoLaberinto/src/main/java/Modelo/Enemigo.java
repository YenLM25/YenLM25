/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import javax.swing.ImageIcon;

/**
 *
 * @author Usuario
 */
public class Enemigo extends Elemento
{
    private int vidas;

    
    
    public Enemigo(int X, int y, ImageIcon imagen) 
    {
        super(X, y, imagen);
    }

    
    public Enemigo(int vidas, int X, int y, ImageIcon imagen) 
    {
        super(X, y, imagen);
        this.vidas = vidas;
    }
    
}

    

