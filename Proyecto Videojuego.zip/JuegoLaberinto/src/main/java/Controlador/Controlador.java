/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Elemento;
import Modelo.Enemigo;
import Modelo.Laberinto;
import Modelo.Principal;
import Vista.GUILaberinto;
import Vista.PanelJuego;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;

/**
 *
 * @author Yendry Leon C24251
 */
public class Controlador implements KeyListener 
{
    private GUILaberinto guiLaberinto;
    private  PanelJuego panelJuego;
    private  Elemento fondo;
    private Principal heroe;
    private Enemigo fantasma;
    private Laberinto laberinto;

     
    
    public  void dibujar(Graphics g)
    {
        fondo.show(g);
        heroe.show(g);
        fantasma.show(g);
        panelJuego.repaint();
    }
    
    public Controlador() 
    {
        fondo = new Elemento(0, 0, new ImageIcon("./src/main/Resources/img/laberinto.gif"));
        heroe = new Principal(1, 40, new ImageIcon("./src/main/Resources/img/personaje.gif"));
        fantasma = new Enemigo(320, 320, new ImageIcon("./src/main/Resources/img/fantasma3.gif"));
        
        laberinto = new Laberinto();
        
        guiLaberinto = new GUILaberinto(this);
        panelJuego = guiLaberinto.getPanelJuego();
        
    }

    @Override
    public void keyTyped(KeyEvent e) 
    {
        
    }

    @Override
public void keyPressed(KeyEvent e) 
{
    int heroeX = heroe.getX();
    int heroeY = heroe.getY();
    int celdaAncho = 40; // Ancho de la celda
    int celdaAltura = 40; // Altura de la celda

    int nuevoX = heroeX;
    int nuevoY = heroeY;

    if (e.getKeyCode() == KeyEvent.VK_UP) 
    {
        nuevoY = heroeY - celdaAltura;
    }
    else if (e.getKeyCode() == KeyEvent.VK_DOWN) 
    {
        nuevoY = heroeY + celdaAltura;
    } 
    else if (e.getKeyCode() == KeyEvent.VK_LEFT) 
    {
        nuevoX = heroeX - celdaAncho;
    } 
    else if (e.getKeyCode() == KeyEvent.VK_RIGHT) 
    {
        nuevoX = heroeX + celdaAncho;
    }

    // Verifica que el héroe no se salga del panel
    if (nuevoX >= 0 && nuevoX + celdaAncho <= panelJuego.getWidth() && nuevoY >= 0 && nuevoY + celdaAltura <= panelJuego.getHeight()) 
    {
        if (laberinto.esCasillaDeCamino(nuevoX, nuevoY, celdaAltura, celdaAncho)) 
        {
            heroe.setX(nuevoX);
            heroe.setY(nuevoY);
        }
    }

    Rectangle heroeHitbox = heroe.getBounds();
    Rectangle enemigoHitbox = fantasma.getBounds();

    if (heroeHitbox.intersects(enemigoHitbox)) 
    {
        System.out.println("El héroe y el enemigo han chocado");
    }
    panelJuego.repaint();
}

    @Override
    public void keyReleased(KeyEvent e) 
    {
    }
    

    
    public static void main(String[] args) 
    {
        new Controlador();
    }
}
